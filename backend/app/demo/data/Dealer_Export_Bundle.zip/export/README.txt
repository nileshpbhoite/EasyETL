Dealer DMS nightly export.
